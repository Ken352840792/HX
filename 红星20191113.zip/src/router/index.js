import Vue from 'vue'
import VueRouter from 'vue-router'
import brand from '@/views/brand/view/index'
import info from '@/views/info/view/index'
import product from '@/views/product/view/index'
Vue.use(VueRouter)
const routes = [
  {
    path: '/',
    name: 'home',
    component: brand
  },
  {
    path: '/info',
    name: 'info',
    component: info
  },
  {
    path: '/product',
    name: 'product',
    component: product
  }
]
const router = new VueRouter({
  routes
})
export default router

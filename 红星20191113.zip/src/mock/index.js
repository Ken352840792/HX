import '@/views/mock.js'
var Mock = require('mockjs')
Mock.setup({
  timeout: 1500
})

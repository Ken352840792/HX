<template>
  <div class="title">
    <h2>{{msg.name}}</h2>
    <button type="text" @click="open">打开</button>
    <button type="text" @click="hideAlert">关闭</button>
    <i class="close-tab glyphicon glyphicon-remove"></i>
  </div>
</template>

<script>
import { mapActions, mapMutations } from 'vuex'
export default {
  data () {
    return {
      msg: ''
    }
  },
  created () {
    var aa = [
      {
        ORGANIZATIONID: '',
        BrandRemark: '',
        VideoID: '',
        VideoTitel: '',
        VideoMainImg: '',
        VideoUrl: '',
        VideoType: '',
        QRCodeURL: '',
        BrandBannerList: [
          {
            Title: '',
            Link: ''
          }
        ]
      }
    ]
    this.init({
      app_key: '',
      method: 'H5.QueryBrandInfo',
      BizParams: JSON.stringify(aa)
    })
  },
  methods: {
    ...mapActions(['getUser']),
    ...mapMutations(['showAlert', 'hideAlert']),
    open () {
      this.showAlert({
        title: '提示',
        msg: '你好',
        buttons: [
          {
            title: '确认',
            callback: () => {
              alert('123')
            }
          },
          {
            title: '取消',
            callback: () => {
              alert('123')
            }
          }
        ]
      })
    },
    async init (params) {
      console.log(3333333)
      // console.log(params)
      var data = await this.getUser(params)
      console.log(data)
      // debugger
      this.msg = data.data
    }
  }
}
</script>
<style lang="scss" scope>
.title {
  // width: 500px;
  // height: 1000px;
  h2 {
    margin: 0 auto;
    text-align: center;
  }
  button {
    padding: 10px 10px;
    border: none;
    color: white;
    border-radius: 5px;
    margin: 20px 500px;
    background-color: #245580;
  }
}
</style>

var Mock = require('mockjs')
Mock.mock(/\/router/, 'post', function (options) {
})

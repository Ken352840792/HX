import Axios from '@/axios/axios'

const actions = {
  // 查询品牌信息接口
  queryBrandInfo ({ commit, state }, params) {
    return Axios.post('/router', getCommQuery(
      'H5.QueryBrandInfo', params
    )).then(res => {
      return res
    })
  },
  // 编辑品牌信息接口
  editBrandInfo ({ commit, state }, params) {
    return Axios.post('/router', getCommQuery(
      'H5.EditBrandInfo', params
    )).then(res => {
      return res
    })
  }
}
function getCommQuery (method, params) {
  return {
    app_key: '123', // 应用的唯一id 由后台给出
    access_token: '456', // 系统登录的标识
    method: method, // 请求的方法名称
    v: 1.0, // 请求的版本号 默认1.0
    sign: '', // 签名加密加密规则
    format: 'json', // 请求结果类型 json or xml 目前只支持json
    BizParams: JSON.stringify(params) // 业务请求的参数
  }
}
const getters = {
  // 对time成员进行过滤，变为格式化时间：名称(state对象参数){}
  getTime (state) {
    var tm = new Date(state.time)
    // return tm.getFullYear() + '-' + (tm.getMonth() + 1) + '-' + tm.getDay()
    return `${tm.getFullYear()}-${tm.getMonth() + 1}-${tm.getDay()}`
  }
}
// mutations：存放同步读取、修改state的的方法
// 改变状态的方法
const mutations = {
  add (state, num) {
    // num传参：每次加...
    state.count += num
  }
}

// 配置共享数据：
const state = {
}
export default {
  actions,
  mutations,
  getters,
  state
}
